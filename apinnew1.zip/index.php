<?php 
session_start();
require_once 'function/functions.php';
if (!isset($_SESSION['username'])) {
  header('Location: login/');
  exit();
}else{
	header("location:./".$_SESSION['lokasi']);
};
?>