	  <footer class="main-footer">
        <div class="footer-left">
          APINS versi <?=$versi;?>
        </div>
        <div class="footer-right">
        </div>
      </footer>