<?php 
session_start();
require_once '../function/functions.php';
if (!isset($_SESSION['username'])) {
  header('Location: ../login/');
  exit();
};
$data['title'] = 'Blank';
//view('template/head', $data);
include "../template/head.php";
?>
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include "../template/top-navbar.php"; ?>
	  <div class="main-sidebar sidebar-style-2">
		<?php 
		switch ($level) {
			case 94: //guru Bahasa Inggris
				include "../template/mapel.php";
				break;
			case 95: //guru PJOK
				include "../template/mapel.php";
				break;
			case 96: //guru PAI
				include "../template/mapel.php";
				break;
			case 97: //guru Pendamping
				include "../template/sidewalas.php";
				break;
			case 98: //guru Kelas
				include "../template/sidewalas.php";
				break;
			case 99: //guru Kepsek
				include "../template/kepsek.php";
				break;
			case 5: //guru Tata Usaha
				include "../template/tatausaha.php";
				break;
			default:
				include "../template/operator.php"; 
				break;
		};
		?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <!-- add content here -->
          </div>
        </section>
		<?php include "../template/setting.php"; ?>
      </div>
      <?php include "../template/footer.php"; ?>
    </div>
  </div>
  <?php include "../template/script.php";?>
</body>
</html>