  <!-- General JS Scripts -->
  <script src="<?= base_url(); ?>assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <script src="<?= base_url(); ?>assets/bundles/datatables/datatables.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/jquery-ui/jquery-ui.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/sweetalert/sweetalert.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/cleave-js/dist/cleave.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/cleave-js/dist/addons/cleave-phone.us.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/jquery-pwstrength/jquery.pwstrength.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/bootstrap-daterangepicker/daterangepicker.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/select2/dist/js/select2.full.min.js"></script>
  <script src="<?= base_url(); ?>assets/bundles/jquery-selectric/jquery.selectric.min.js"></script>
  <!-- Template JS File -->
  <script src="<?= base_url(); ?>assets/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="<?= base_url(); ?>assets/js/custom.js"></script>